State of Brain Emulation Report 2025 - Generated Figures
============================================================

This archive contains 43 figures from the State of Brain Emulation Report 2025.

Contents:
- PNG files (150 DPI, suitable for web and presentations)
- SVG files (vector format, suitable for editing and high-resolution printing)

License: CC BY 4.0 (Creative Commons Attribution 4.0 International)
Attribution: Zanichelli, Schons et al., State of Brain Emulation Report 2025

For more information, visit the report website or see LICENSE.txt.

Generated: 2026-01-19
